var initialChoice;
var situationText;
//var $form = $("#userSituationInput");
//var $input = $form.find("input[name=situationText]");
//var userData = {};

$('.initialHappy').click(function(e) {
    e.preventDefault();

    initialHappyChoice();
});

$('.initialSad').click(function(e) {
    e.preventDefault();

    initialSadChoice();
});

function initialHappyChoice(){
    initialChoice = "Happy"
    $('.homeContent').hide();
    $('.homeInput').hide();
    $('.happySituationContent').show();
    $('.situationInput').show();
    $('.userHappySubmit').show();
};

function initialSadChoice(){
    initialChoice = "Sad"
    $('.homeContent').hide();
    $('.homeInput').hide();
    $('.sadSituationContent').show();
    $('.situationInput').show();
    $('.userSadSubmit').show();
};

$("input").keyup(function(e){
    e.preventDefault();

    situationText = $( this ).val();
    console.log(situationText);
});

/*$form.submit(function(e){
    e.preventDefault();

    situationText = ($input.val());


    alert(situationText);
});
*/

/*
$('input').keyup(function(){
    userData[this.id] = $(this).val();
    print = userData.userSituation;
    console.log(print);
});
*/

$('.happySubmit').click(function(e) {
    e.preventDefault();

    $('.happySituationContent').hide();
    $('.userHappySubmit').hide();
    $('p.userSituation').text(situationText);
    $('.userSituation').show();
    $('.happyFeelingInput').show();
});

$('.sadSubmit').click(function(e) {
    e.preventDefault();

    $('.sadSituationContent').hide();
    $('.situationInput').hide();
    $('div.userSituation, p').text( 'situationText' );
    $('.userSituation').show();
});
